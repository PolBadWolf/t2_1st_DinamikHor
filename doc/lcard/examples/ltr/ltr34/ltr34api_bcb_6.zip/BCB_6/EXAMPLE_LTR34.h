//---------------------------------------------------------------------------

#ifndef EXAMPLE_LTR34H
#define EXAMPLE_LTR34H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
        TLabel *Label18;
        TLabel *Label19;
        TButton *RESET_Button;
        TComboBox *CRATE_Combo;
        TComboBox *MODULE_Combo;
        TMemo *Memo1;
        TPanel *Panel2;
        TStatusBar *StatusBar1;
        TButton *STREAM_START;
        TButton *STREAM_STOP;
        TCheckBox *CHON_1;
        TLabel *Label1;
        TLabel *Label4;
        TCheckBox *CHON_2;
        TCheckBox *CHON_3;
        TCheckBox *CHON_4;
        TCheckBox *CHON_5;
        TCheckBox *CHON_6;
        TCheckBox *CHON_7;
        TCheckBox *CHON_8;
        TComboBox *OUT_SEL_1;
        TComboBox *OUT_SEL_2;
        TComboBox *OUT_SEL_3;
        TComboBox *OUT_SEL_4;
        TComboBox *OUT_SEL_5;
        TComboBox *OUT_SEL_6;
        TComboBox *OUT_SEL_7;
        TComboBox *OUT_SEL_8;
        TGroupBox *GroupBox1;
        TCSpinEdit *FRQ_ID_SEL;
        TLabel *Label5;
        TEdit *Edit19;
        TLabel *Label6;
        TLabel *Label7;
        TLabel *Label8;
        TEdit *Edit20;
        TRadioGroup *GEN_MODE_LED;
        TTimer *Timer1;
        TPanel *Panel3;
        TLabel *Label2;
        TLabel *Label3;
        TEdit *Edit1;
        TButton *SET_CH1;
        TEdit *Edit2;
        TEdit *Edit3;
        TEdit *Edit4;
        TButton *SET_CH2;
        TEdit *Edit5;
        TEdit *Edit6;
        TButton *SET_CH3;
        TEdit *Edit7;
        TEdit *Edit8;
        TButton *SET_CH4;
        TEdit *Edit9;
        TEdit *Edit10;
        TButton *SET_CH5;
        TEdit *Edit11;
        TEdit *Edit12;
        TButton *SET_CH6;
        TEdit *Edit13;
        TEdit *Edit14;
        TButton *SET_CH7;
        TEdit *Edit15;
        TEdit *Edit16;
        TButton *SET_CH8;
        TPanel *Panel4;
        TPanel *Panel5;
        void __fastcall RESET_ButtonClick(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FRQ_ID_SELChange(TObject *Sender);
        void __fastcall CHON_1Click(TObject *Sender);
        void __fastcall SET_CH1Click(TObject *Sender);
        void __fastcall STREAM_STARTClick(TObject *Sender);
        void __fastcall Timer1Timer(TObject *Sender);
        void __fastcall SET_CH2Click(TObject *Sender);
        void __fastcall SET_CH3Click(TObject *Sender);
        void __fastcall SET_CH4Click(TObject *Sender);
        void __fastcall SET_CH5Click(TObject *Sender);
        void __fastcall SET_CH6Click(TObject *Sender);
        void __fastcall SET_CH7Click(TObject *Sender);
        void __fastcall SET_CH8Click(TObject *Sender);
        void __fastcall STREAM_STOPClick(TObject *Sender);
        void __fastcall OUT_SEL_1Change(TObject *Sender);
        void __fastcall CRATE_ComboChange(TObject *Sender);
        void __fastcall MODULE_ComboChange(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
