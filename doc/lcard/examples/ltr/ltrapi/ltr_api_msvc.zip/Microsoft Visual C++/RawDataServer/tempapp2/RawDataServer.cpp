// tempapp2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"


#include "ltr\include\ltrapi.h"
#include "ltr\include\ltr22api.h"
#include "ltr\include\ltrapidefine.h"

#define NumRawData	(1024)
int _tmain(int argc, _TCHAR* argv[])
{	
	TLTR module;
	DWORD data[NumRawData];
	double VoltsData[NumRawData];	
	LTR_Init(&module);
	module.cc=CC_RAW_DATA_FLAG;	
	
	int res=LTR_Open(&module);

	TLTR22 moduleWork;	
	LTR22_Init(&moduleWork);
	res=LTR22_Open(&moduleWork,0,0,moduleWork.Channel.csn,2);
	res=LTR22_StartADC(&moduleWork,false);		

	res=LTR_GetCrateRawData(&module, data,NULL,NumRawData,1000);	
	res=LTR22_ProcessData(&moduleWork, data,VoltsData,NumRawData, true, true, NULL);

	LTR22_StopADC(&moduleWork);
	LTR22_Close(&moduleWork);

	LTR_Close(&module);	

	return 0;
}
