//---------------------------------------------------------------------------
//   ���� LTR11
//---------------------------------------------------------------------------
#include <stdio.h>
#include <conio.h>
#include "ltr\\include\\ltrapi.h"
#include "ltr\\include\\ltrapidefine.h"
#include "ltr\\include\\ltr11api.h"
#define NumRawData	(16)
//---------------------------------------------------------------------------
void main(void)
{ 
	int i,nslot;
	INT res,data_size;
	TLTR module;
	TLTR11 hltr11;
	DWORD data[NumRawData];
	double VoltsData[NumRawData];

	LTR_Init(&module);
	module.cc=CC_CONTROL;
	LTR_Open(&module);
	LTR11_Init(&hltr11);
	nslot=10;  //����� ����� ������ 11
	res=LTR11_Open(&hltr11, SADDR_DEFAULT, SPORT_DEFAULT, "", nslot);
	if(res==LTR_OK) {
		printf("LTR11 Open OK\n");
		res=LTR11_GetConfig(&hltr11);
		if(res==LTR_OK) {
			printf("LTR11 getconfig OK\n");
			hltr11.InpMode=LTR11_INPMODE_INT;
			hltr11.LChQnt=16;
			for(i=0;i<16;i++) hltr11.LChTbl[i]=(BYTE)i;
			hltr11.ADCMode=LTR11_ADCMODE_ACQ;
			hltr11.ADCRate.divider=36;
			hltr11.ADCRate.prescaler=8;
			res=LTR11_SetADC(&hltr11);
			if(res==LTR_OK) {
				printf("LTR11 setadc OK\n");
				LTR11_Start(&hltr11);
			}
		}
	}
	while(!kbhit()) { // ��������� � ����������
		LTR_GetCrateRawData(&module, data,NULL,NumRawData,1000);
		data_size=NumRawData;
		res=LTR11_ProcessData(&hltr11, data, VoltsData, &data_size, TRUE, TRUE);
		if(res==0) printf(" res=%00004d %10.4f %10.4f %10.4f\n",res,VoltsData[0],VoltsData[1],VoltsData[2]);
	}
	LTR11_Stop(&hltr11);
	LTR11_Close(&hltr11);
	LTR_Close(&module);
	printf(" fin programm");
	return;
}

