//---------------------------------------------------------------------------

#ifndef LTR114_TestH
#define LTR114_TestH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "CSPIN.h"
#include "ltr/include/ltr114api.h"
#include "LTR114_ProcessThread.h"
#include <VCL/syncobjs.hpp>
//---------------------------------------------------------------------------
class TLTR114TestForm : public TForm
{
__published:	// IDE-managed Components
        TGroupBox *GroupBox1;
        TComboBox *SyncModeBox;
        TLabel *Label4;
        TComboBox *AutocbrModeBox;
        TLabel *Label2;
        TEdit *FreqEdit;
        TLabel *Label3;
        TLabel *Label5;
        TLabel *Label6;
        TCSpinEdit *FreqDividerSpin;
        TCSpinEdit *IntervalSpin;
        TLabel *Label7;
        TButton *StartButton;
        TButton *StopButton;
        TGroupBox *ResultsGroup;
        TLabel *Label8;
        TLabel *Label9;
        TLabel *Label10;
        TLabel *Label11;
        TEdit *LCh1Edit;
        TComboBox *LCH1_GainBox;
        TComboBox *LCH1_ModeBox;
        TEdit *LCh2Edit;
        TComboBox *LCH2_GainBox;
        TComboBox *LCH2_ModeBox;
        TEdit *LCh3Edit;
        TComboBox *LCH3_GainBox;
        TComboBox *LCH3_ModeBox;
        TEdit *LCh4Edit;
        TComboBox *LCH4_GainBox;
        TComboBox *LCH4_ModeBox;
        TComboBox *LCH1_ChannelBox;
        TComboBox *LCH2_ChannelBox;
        TComboBox *LCH3_ChannelBox;
        TComboBox *LCH4_ChannelBox;
        TCheckBox *ThermCheckBox;
        TEdit *ThermEdit;
        TCSpinEdit *LChCntEdit;
        TButton *FindLtrButton;
        TComboBox *CratesBox;
        TComboBox *ModulesBox;
        void __fastcall StartButtonClick(TObject *Sender);
        void __fastcall StopButtonClick(TObject *Sender);
        void __fastcall FreqDividerSpinChange(TObject *Sender);
        void __fastcall FindLtrButtonClick(TObject *Sender);
        void __fastcall CratesBoxChange(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
        ltr114_ProcessThread *ltr_thread;

        void ButtonEndis(bool start);
        LTR114_LCHANNEL SetChannel(int index);
        TLTR114 hltr114;
        TCriticalSection *crit_sect; //���� ������ ��� ���������� thread_run
        bool thread_run;
        __fastcall void OnThreadTerminate(TObject *obj);
        bool ThreadIsRun();


public:		// User declarations
        __fastcall TLTR114TestForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TLTR114TestForm *LTR114TestForm;
//---------------------------------------------------------------------------
#endif
