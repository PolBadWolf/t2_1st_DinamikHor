#include <stdio.h>

int main
(
	void
)
{
	int cnt_read;
	double data;
	FILE *fin;
	FILE *fout;
	const int qnt_ch = 4;


	fin = fopen("adc_data.bin", "rb");
	fout = fopen("adc_data.txt", "w");

	cnt_read = qnt_ch;
	while ((fread(&data, sizeof(double), 1, fin) == 1))
	{
		fprintf(fout, "%g ", data);
		if (--cnt_read == 0)
		{
			fputc('\n', fout);
			cnt_read = qnt_ch;
		}
	}

	fclose(fout);
	fclose(fin);

	return 0;
}